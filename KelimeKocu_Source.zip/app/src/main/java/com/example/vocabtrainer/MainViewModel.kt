package com.example.vocabtrainer

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vocabtrainer.ai.AiQuestion
import com.example.vocabtrainer.ai.AiQuestionService
import com.example.vocabtrainer.data.WordEntity
import com.example.vocabtrainer.data.WordRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo: WordRepository = (app as VocabApp).repository
    private val ai = AiQuestionService()

    val all = repo.all.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val learning = repo.learning.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val learned = repo.learned.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _quizWord = MutableStateFlow<WordEntity?>(null)
    val quizWord = _quizWord.asStateFlow()

    private val _aiQuestion = MutableStateFlow<AiQuestion?>(null)
    val aiQuestion = _aiQuestion.asStateFlow()

    fun add(english: String, turkish: String, note: String) = viewModelScope.launch {
        if (english.isNotBlank() && turkish.isNotBlank()) repo.add(english, turkish, note)
    }

    fun nextQuiz() = viewModelScope.launch {
        val due = repo.dueWords()
        _quizWord.value = (due.ifEmpty { repo.randomWords(20) }).randomOrNull()
        _aiQuestion.value = null
    }

    fun grade(quality: Int) = viewModelScope.launch {
        _quizWord.value?.let {
            repo.grade(it, quality)
            nextQuiz()
        }
    }

    fun markLearned(word: WordEntity) = viewModelScope.launch {
        repo.update(word.copy(status = com.example.vocabtrainer.data.WordStatus.LEARNED))
    }

    fun markLearning(word: WordEntity) = viewModelScope.launch {
        repo.update(word.copy(status = com.example.vocabtrainer.data.WordStatus.LEARNING))
    }

    fun delete(word: WordEntity) = viewModelScope.launch { repo.delete(word) }

    fun generateAiQuestion(backendUrl: String, token: String) = viewModelScope.launch {
        val word = _quizWord.value ?: return@launch
        _aiQuestion.value = if (backendUrl.isBlank()) {
            ai.localFallback(word)
        } else {
            ai.generate(backendUrl, token, word).getOrElse { ai.localFallback(word) }
        }
    }
}
