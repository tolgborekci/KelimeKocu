package com.example.vocabtrainer.ai

import com.example.vocabtrainer.data.WordEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class AiQuestion(
    val question: String,
    val answer: String,
    val explanation: String = ""
)

class AiQuestionService {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Güvenlik için API anahtarını APK içine gömmeyin.
     * Bu fonksiyon kendi backend'inizde oluşturacağınız /generate-question endpoint'ine gider.
     *
     * Beklenen istek:
     * {"english":"undergo","turkish":"maruz kalmak/geçirmek","level":"YDS"}
     *
     * Beklenen yanıt:
     * {"question":"...","answer":"...","explanation":"..."}
     */
    suspend fun generate(
        backendUrl: String,
        authToken: String,
        word: WordEntity,
        level: String = "YDS 70+"
    ): Result<AiQuestion> = withContext(Dispatchers.IO) {
        runCatching {
            val bodyJson = JSONObject().apply {
                put("english", word.english)
                put("turkish", word.turkish)
                put("level", level)
                put("instruction",
                    "Create one English vocabulary question using the target word. " +
                    "Use a natural academic/YDS-style sentence. Return JSON only.")
            }

            val requestBody = bodyJson.toString()
                .toRequestBody("application/json; charset=utf-8".toMediaType())

            val request = Request.Builder()
                .url(backendUrl.trimEnd('/') + "/generate-question")
                .header("Authorization", "Bearer $authToken")
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) error("AI service error: ${response.code}")
                val json = JSONObject(response.body?.string().orEmpty())
                AiQuestion(
                    question = json.getString("question"),
                    answer = json.getString("answer"),
                    explanation = json.optString("explanation")
                )
            }
        }
    }

    fun localFallback(word: WordEntity): AiQuestion =
        AiQuestion(
            question = "Which option best completes the sentence?\n\n" +
                    "The company had to ______ a major restructuring process.\n\n" +
                    "Target word: ${word.english}",
            answer = word.english,
            explanation = "Kelime: ${word.english} = ${word.turkish}"
        )
}
