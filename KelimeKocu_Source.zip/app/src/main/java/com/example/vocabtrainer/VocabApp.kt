package com.example.vocabtrainer

import android.app.Application
import com.example.vocabtrainer.data.AppDatabase
import com.example.vocabtrainer.data.WordRepository
import com.example.vocabtrainer.notifications.ReviewScheduler

class VocabApp : Application() {
    val database by lazy { AppDatabase.get(this) }
    val repository by lazy { WordRepository(database.wordDao()) }

    override fun onCreate() {
        super.onCreate()
        ReviewScheduler.createNotificationChannel(this)
        ReviewScheduler.scheduleDailyReview(this)
    }
}
