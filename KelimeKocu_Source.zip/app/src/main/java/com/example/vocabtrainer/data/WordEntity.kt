package com.example.vocabtrainer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class WordStatus { LEARNING, LEARNED }

@Entity(tableName = "words")
data class WordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val english: String,
    val turkish: String,
    val note: String = "",
    val status: WordStatus = WordStatus.LEARNING,
    val createdAt: Long = System.currentTimeMillis(),
    val nextReviewAt: Long = System.currentTimeMillis(),
    val intervalDays: Int = 0,
    val repetition: Int = 0,
    val easeFactor: Double = 2.5,
    val correctCount: Int = 0,
    val wrongCount: Int = 0
)
