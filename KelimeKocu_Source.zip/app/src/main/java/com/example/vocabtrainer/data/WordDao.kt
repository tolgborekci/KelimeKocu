package com.example.vocabtrainer.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WordDao {
    @Query("SELECT * FROM words ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE status = :status ORDER BY nextReviewAt ASC")
    fun observeByStatus(status: WordStatus): Flow<List<WordEntity>>

    @Query("SELECT * FROM words WHERE nextReviewAt <= :now AND status = 'LEARNING' ORDER BY nextReviewAt ASC")
    suspend fun dueWords(now: Long): List<WordEntity>

    @Insert
    suspend fun insert(word: WordEntity)

    @Update
    suspend fun update(word: WordEntity)

    @Delete
    suspend fun delete(word: WordEntity)

    @Query("SELECT * FROM words ORDER BY RANDOM() LIMIT :count")
    suspend fun randomWords(count: Int): List<WordEntity>
}
