package com.example.vocabtrainer.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun statusToString(status: WordStatus) = status.name

    @TypeConverter
    fun stringToStatus(value: String) = WordStatus.valueOf(value)
}
