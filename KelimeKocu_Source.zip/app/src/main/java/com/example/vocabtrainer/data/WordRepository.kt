package com.example.vocabtrainer.data

class WordRepository(private val dao: WordDao) {
    val all = dao.observeAll()
    val learning = dao.observeByStatus(WordStatus.LEARNING)
    val learned = dao.observeByStatus(WordStatus.LEARNED)

    suspend fun add(english: String, turkish: String, note: String) {
        dao.insert(
            WordEntity(
                english = english.trim(),
                turkish = turkish.trim(),
                note = note.trim()
            )
        )
    }

    suspend fun dueWords() = dao.dueWords(System.currentTimeMillis())
    suspend fun randomWords(count: Int) = dao.randomWords(count)
    suspend fun update(word: WordEntity) = dao.update(word)
    suspend fun delete(word: WordEntity) = dao.delete(word)

    suspend fun grade(word: WordEntity, quality: Int) {
        // SM-2 benzeri basitleştirilmiş aralıklı tekrar.
        val q = quality.coerceIn(0, 5)
        val failed = q < 3

        val newRepetition = if (failed) 0 else word.repetition + 1
        val newInterval = when {
            failed -> 0
            newRepetition == 1 -> 1
            newRepetition == 2 -> 3
            else -> (word.intervalDays.coerceAtLeast(3) * word.easeFactor).toInt().coerceAtLeast(4)
        }

        val newEase = (word.easeFactor +
            (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)))
            .coerceAtLeast(1.3)

        val next = if (failed) {
            System.currentTimeMillis() + 10 * 60 * 1000L // 10 dk sonra tekrar
        } else {
            System.currentTimeMillis() + newInterval * 24L * 60L * 60L * 1000L
        }

        dao.update(
            word.copy(
                repetition = newRepetition,
                intervalDays = newInterval,
                easeFactor = newEase,
                nextReviewAt = next,
                correctCount = word.correctCount + if (failed) 0 else 1,
                wrongCount = word.wrongCount + if (failed) 1 else 0,
                status = if (!failed && newRepetition >= 5) WordStatus.LEARNED else WordStatus.LEARNING
            )
        )
    }
}
