package com.example.vocabtrainer

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.vocabtrainer.data.WordEntity
import com.example.vocabtrainer.data.WordStatus

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VocabTrainerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VocabTrainerApp(vm: MainViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) {}

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Kelime Koçu") },
                    actions = {
                        Icon(Icons.Default.School, contentDescription = null)
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf(
                        Triple("Kelimeler", Icons.Default.List, 0),
                        Triple("Tekrar", Icons.Default.Quiz, 1),
                        Triple("Ayarlar", Icons.Default.Settings, 2)
                    ).forEach { (label, icon, index) ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (tab) {
                    0 -> WordListScreen(vm)
                    1 -> QuizScreen(vm)
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun WordListScreen(vm: MainViewModel) {
    val words by vm.all.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf<WordStatus?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Kelime Havuzu", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
            Button(onClick = { showAdd = true }) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Ekle")
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(filter == null, { filter = null }, { Text("Tümü") })
            FilterChip(filter == WordStatus.LEARNING, { filter = WordStatus.LEARNING }, { Text("Öğreniyorum") })
            FilterChip(filter == WordStatus.LEARNED, { filter = WordStatus.LEARNED }, { Text("Öğrendim") })
        }

        Spacer(Modifier.height(12.dp))

        val filtered = words.filter { filter == null || it.status == filter }
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Henüz kelime yok. İlk kelimeni ekle.")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filtered, key = { it.id }) { word ->
                    WordCard(word, vm)
                }
            }
        }
    }

    if (showAdd) {
        AddWordDialog(
            onDismiss = { showAdd = false },
            onAdd = { en, tr, note ->
                vm.add(en, tr, note)
                showAdd = false
            }
        )
    }
}

@Composable
fun WordCard(word: WordEntity, vm: MainViewModel) {
    Card {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row {
                Column(Modifier.weight(1f)) {
                    Text(word.english, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(word.turkish)
                    if (word.note.isNotBlank()) Text(word.note, style = MaterialTheme.typography.bodySmall)
                }
                AssistChip(
                    onClick = {},
                    label = { Text(if (word.status == WordStatus.LEARNED) "Öğrendim" else "Öğreniyorum") }
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "Doğru: ${word.correctCount}  •  Yanlış: ${word.wrongCount}  •  Aralık: ${word.intervalDays} gün",
                style = MaterialTheme.typography.bodySmall
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = {
                    if (word.status == WordStatus.LEARNED) vm.markLearning(word) else vm.markLearned(word)
                }) {
                    Text(if (word.status == WordStatus.LEARNED) "Tekrar öğren" else "Öğrendim")
                }
                TextButton(onClick = { vm.delete(word) }) { Text("Sil") }
            }
        }
    }
}

@Composable
fun AddWordDialog(onDismiss: () -> Unit, onAdd: (String, String, String) -> Unit) {
    var en by remember { mutableStateOf("") }
    var tr by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kelime ekle") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(en, { en = it }, label = { Text("İngilizce") })
                OutlinedTextField(tr, { tr = it }, label = { Text("Türkçe anlamı") })
                OutlinedTextField(note, { note = it }, label = { Text("Not / örnek") })
            }
        },
        confirmButton = {
            Button(onClick = { onAdd(en, tr, note) }, enabled = en.isNotBlank() && tr.isNotBlank()) {
                Text("Kaydet")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

@Composable
fun QuizScreen(vm: MainViewModel) {
    val word by vm.quizWord.collectAsState()
    val aiQuestion by vm.aiQuestion.collectAsState()
    var showAnswer by remember { mutableStateOf(false) }
    var backend by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { vm.nextQuiz() }
    LaunchedEffect(word?.id) { showAnswer = false }

    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Aralıklı Tekrar", style = MaterialTheme.typography.headlineSmall)

        if (word == null) {
            Text("Soru oluşturmak için önce kelime ekle.")
            return@Column
        }

        Card {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Bu kelimenin Türkçe karşılığı nedir?", style = MaterialTheme.typography.labelLarge)
                Text(word!!.english, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

                if (showAnswer) {
                    Divider()
                    Text("Cevap: ${word!!.turkish}", fontWeight = FontWeight.Bold)
                    if (word!!.note.isNotBlank()) Text(word!!.note)

                    Text("Kendini değerlendir:")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = { vm.grade(1) }) { Text("Tekrar") }
                        Button(onClick = { vm.grade(3) }) { Text("Zor") }
                        Button(onClick = { vm.grade(4) }) { Text("İyi") }
                        Button(onClick = { vm.grade(5) }) { Text("Kolay") }
                    }
                } else {
                    Button(onClick = { showAnswer = true }) { Text("Cevabı Göster") }
                }
            }
        }

        OutlinedTextField(
            value = backend,
            onValueChange = { backend = it },
            label = { Text("AI backend URL (opsiyonel)") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = token,
            onValueChange = { token = it },
            label = { Text("AI erişim tokenı (opsiyonel)") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(onClick = { vm.generateAiQuestion(backend, token) }) {
            Icon(Icons.Default.AutoAwesome, null)
            Spacer(Modifier.width(6.dp))
            Text("AI ile soru oluştur")
        }

        aiQuestion?.let {
            Card {
                Column(Modifier.padding(16.dp)) {
                    Text("AI Sorusu", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(it.question)
                    Spacer(Modifier.height(8.dp))
                    Text("Cevap: ${it.answer}")
                    if (it.explanation.isNotBlank()) Text(it.explanation, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Ayarlar", style = MaterialTheme.typography.headlineSmall)
        Text("• Günlük tekrar bildirimi otomatik olarak planlanır.")
        Text("• Yanlış cevaplanan kelime 10 dakika sonra tekrar sorulur.")
        Text("• Doğru cevaplarda tekrar aralığı 1 gün → 3 gün → daha uzun aralıklara çıkar.")
        Text("• 5 başarılı tekrar sonrası kelime 'Öğrendim' grubuna geçer.")
        Text("• AI anahtarını APK içine gömmek yerine kendi backend servisini kullan.")
    }
}
