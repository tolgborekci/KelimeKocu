package com.example.vocabtrainer.notifications

import android.Manifest
import android.app.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.example.vocabtrainer.R
import com.example.vocabtrainer.data.AppDatabase
import java.util.concurrent.TimeUnit

object ReviewScheduler {
    private const val CHANNEL_ID = "word_review"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kelime tekrarları",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Tekrar zamanı gelen kelimeler için bildirim"
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    fun scheduleDailyReview(context: Context) {
        val request = PeriodicWorkRequestBuilder<ReviewWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(1, TimeUnit.HOURS)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "daily_word_review",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    internal fun notify(context: Context, count: Int) {
        if (count <= 0) return
        if (Build.VERSION.SDK_INT >= 33 &&
            context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Kelime tekrar zamanı")
            .setContentText("$count kelime seni bekliyor.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        NotificationManagerCompat.from(context).notify(1001, notification)
    }
}

class ReviewWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val due = AppDatabase.get(applicationContext)
            .wordDao()
            .dueWords(System.currentTimeMillis())
        ReviewScheduler.notify(applicationContext, due.size)
        return Result.success()
    }
}
