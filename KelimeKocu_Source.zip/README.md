# Kelime Koçu — Android / Samsung

Kotlin + Jetpack Compose ile hazırlanmış basit bir kelime öğrenme uygulaması.

## Özellikler
- İngilizce kelime ve Türkçe anlam ekleme
- Room veritabanına kalıcı kayıt
- Öğreniyorum / Öğrendim grupları
- SM-2 benzeri aralıklı tekrar
- Yanlış kelimeyi 10 dakika sonra tekrar sorma
- Günlük tekrar bildirimi (WorkManager)
- Doğru / yanlış istatistikleri
- AI destekli soru üretmek için backend entegrasyon noktası
- Backend yoksa yerel soru şablonu

## Android Studio ile çalıştırma
1. Android Studio'yu aç.
2. `VocabTrainer` klasörünü `Open` ile aç.
3. Gradle Sync tamamlanmasını bekle.
4. Samsung telefonunda:
   - Geliştirici seçeneklerini aç
   - USB debugging'i etkinleştir
   - USB ile PC'ye bağla
5. Android Studio'da cihazı seçip Run tuşuna bas.

## AI Entegrasyonu
Uygulama doğrudan bir yapay zeka servisinin gizli API anahtarını APK içine koymaz.
`AiQuestionService.kt` içindeki kod şu endpoint'i bekler:

POST /generate-question

Request:
```json
{
  "english": "undergo",
  "turkish": "geçirmek / maruz kalmak",
  "level": "YDS 70+",
  "instruction": "Create one English vocabulary question..."
}
```

Response:
```json
{
  "question": "The patient had to ____ a series of tests.",
  "answer": "undergo",
  "explanation": "undergo = geçirmek / maruz kalmak"
}
```

Backend adresi boş bırakılırsa uygulama çevrimdışı örnek soru üretir.

## Sonraki geliştirmeler
- Çoktan seçmeli 4 şık
- İngilizce → Türkçe / Türkçe → İngilizce yön seçimi
- Sesli telaffuz (TextToSpeech)
- Excel/CSV kelime içe aktarma
- Bulut yedekleme
- Seviye bazlı soru üretimi (YDS 60/70/80+)
- AI açıklaması ve eş anlamlılar
